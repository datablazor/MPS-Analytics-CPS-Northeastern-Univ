CREATE DATABASE  IF NOT EXISTS `hr_training` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `hr_training`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hr_training
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `class_registrations`
--

DROP TABLE IF EXISTS `class_registrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class_registrations` (
  `reg_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `date_registered` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `completed` bit(1) NOT NULL DEFAULT b'0',
  `passed` bit(1) DEFAULT NULL,
  `comments` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`reg_id`),
  KEY `emp_id_idx` (`emp_id`),
  KEY `class_id_idx` (`class_id`),
  CONSTRAINT `FK_emp_class_reg_idx` FOREIGN KEY (`emp_id`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_training_class_idx` FOREIGN KEY (`class_id`) REFERENCES `training_classes` (`class_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class_registrations`
--

LOCK TABLES `class_registrations` WRITE;
/*!40000 ALTER TABLE `class_registrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `class_registrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `current_employee_contact_list`
--

DROP TABLE IF EXISTS `current_employee_contact_list`;
/*!50001 DROP VIEW IF EXISTS `current_employee_contact_list`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `current_employee_contact_list` AS SELECT 
 1 AS `Employee Name`,
 1 AS `Badge`,
 1 AS `Department`,
 1 AS `shift`,
 1 AS `position_title`,
 1 AS `address_1`,
 1 AS `city`,
 1 AS `state_province`,
 1 AS `postal_code`,
 1 AS `phone_1`,
 1 AS `phone_2`,
 1 AS `email`,
 1 AS `emp_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_number` varchar(10) DEFAULT NULL,
  `dept_name` varchar(45) NOT NULL,
  `dept_head` int(11) DEFAULT NULL,
  PRIMARY KEY (`dept_id`),
  KEY `dept_number_idx` (`dept_number`),
  KEY `dept_name_idx` (`dept_name`),
  KEY `FK_dept_head_idx_idx` (`dept_head`),
  CONSTRAINT `FK_dept_head_idx` FOREIGN KEY (`dept_head`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'101','Human Resources',NULL),(2,'102','Administration',NULL),(3,'103','Production',5),(4,'104','Accounting',NULL),(5,'105','Information Technology',1),(6,'106','Maintenance',NULL);
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_alt`
--

DROP TABLE IF EXISTS `employee_alt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_alt` (
  `emp_id` int(11) NOT NULL,
  `SSN` varchar(12) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `address_1` varchar(35) DEFAULT NULL,
  `address_2` varchar(35) DEFAULT NULL,
  `city` varchar(25) DEFAULT NULL,
  `state_province` varchar(10) DEFAULT NULL,
  `postal_code` varchar(15) DEFAULT NULL,
  `phone_1` varchar(15) DEFAULT NULL,
  `phone_2` varchar(15) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_phone` varchar(15) DEFAULT NULL,
  `contact_relation` varchar(25) DEFAULT NULL,
  UNIQUE KEY `emp_id_UNIQUE` (`emp_id`),
  KEY `ssn_idx` (`SSN`),
  KEY `dob_idx` (`DOB`),
  KEY `city_idx` (`city`),
  CONSTRAINT `FK_emp_alt_idx` FOREIGN KEY (`emp_id`) REFERENCES `employee_main` (`emp_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_alt`
--

LOCK TABLES `employee_alt` WRITE;
/*!40000 ALTER TABLE `employee_alt` DISABLE KEYS */;
/*!40000 ALTER TABLE `employee_alt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_main`
--

DROP TABLE IF EXISTS `employee_main`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_main` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `badge_no` varchar(10) DEFAULT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `mid_name` varchar(25) DEFAULT NULL,
  `photo` blob,
  `dept_id` int(11) DEFAULT NULL,
  `shift` int(11) DEFAULT NULL,
  `position_id` int(11) DEFAULT NULL,
  `hire_date` date NOT NULL,
  `start_date` date DEFAULT NULL,
  `current` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `badge_no_UNIQUE` (`badge_no`),
  KEY `badge_no_idx` (`badge_no`),
  KEY `last_name_idx` (`last_name`),
  KEY `dept_id_idx` (`dept_id`),
  KEY `shift_idx` (`shift`),
  KEY `hire_date_idx` (`hire_date`),
  KEY `FK_position_idx_idx` (`position_id`),
  CONSTRAINT `FK_department_idx` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_position_idx` FOREIGN KEY (`position_id`) REFERENCES `positions` (`position_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_main`
--

LOCK TABLES `employee_main` WRITE;
/*!40000 ALTER TABLE `employee_main` DISABLE KEYS */;
INSERT INTO `employee_main` VALUES (1,NULL,'Andrew','Comeau',NULL,NULL,5,NULL,2,'2015-07-19',NULL,'');
/*!40000 ALTER TABLE `employee_main` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_record`
--

DROP TABLE IF EXISTS `employee_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee_record` (
  `rec_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) DEFAULT NULL,
  `record_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `action_type` varchar(15) NOT NULL,
  `notes` varchar(2048) DEFAULT NULL,
  `record_by` int(11) NOT NULL,
  PRIMARY KEY (`rec_id`),
  KEY `emp_id_idx` (`emp_id`),
  KEY `record_date_idx` (`record_date`),
  KEY `action_type_idx` (`action_type`),
  KEY `record_by_idx` (`record_by`),
  CONSTRAINT `FK_emp_record_idx` FOREIGN KEY (`emp_id`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_record`
--

LOCK TABLES `employee_record` WRITE;
/*!40000 ALTER TABLE `employee_record` DISABLE KEYS */;
INSERT INTO `employee_record` VALUES (1,1,'2015-04-01 00:00:00','Hire','None',1);
/*!40000 ALTER TABLE `employee_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ext_instructors`
--

DROP TABLE IF EXISTS `ext_instructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ext_instructors` (
  `instructor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) NOT NULL,
  `first_name` varchar(25) NOT NULL,
  `last_name` varchar(25) NOT NULL,
  `cert_info` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`instructor_id`),
  KEY `vendor_id_idx` (`vendor_id`),
  KEY `last_name_idx` (`last_name`),
  CONSTRAINT `FK_instructor_vendor_idx` FOREIGN KEY (`vendor_id`) REFERENCES `training_vendors` (`vendor_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ext_instructors`
--

LOCK TABLES `ext_instructors` WRITE;
/*!40000 ALTER TABLE `ext_instructors` DISABLE KEYS */;
/*!40000 ALTER TABLE `ext_instructors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `past_employees`
--

DROP TABLE IF EXISTS `past_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `past_employees` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `term_date` date NOT NULL,
  `term_type` enum('Quit','Dismissed','Layoff','Deceased') DEFAULT NULL,
  `comments` varchar(2048) DEFAULT NULL,
  `rehire` bit(1) DEFAULT b'1',
  PRIMARY KEY (`emp_id`),
  KEY `term_date_idx` (`term_date`),
  KEY `term_type_idx` (`term_type`),
  CONSTRAINT `FK_past_emp_idx` FOREIGN KEY (`emp_id`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `past_employees`
--

LOCK TABLES `past_employees` WRITE;
/*!40000 ALTER TABLE `past_employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `past_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `positions`
--

DROP TABLE IF EXISTS `positions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `positions` (
  `position_id` int(11) NOT NULL AUTO_INCREMENT,
  `dept_id` int(11) DEFAULT NULL,
  `position_title` varchar(45) NOT NULL,
  `position_desc` varchar(2048) DEFAULT NULL,
  `pay_grade` int(11) DEFAULT NULL,
  `hourly` bit(1) DEFAULT b'1',
  `supervsiory` bit(1) DEFAULT b'0',
  PRIMARY KEY (`position_id`),
  KEY `dept_id_idx` (`dept_id`),
  KEY `pos_title_idx` (`position_title`),
  CONSTRAINT `FK_dept_id_idx` FOREIGN KEY (`dept_id`) REFERENCES `departments` (`dept_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `positions`
--

LOCK TABLES `positions` WRITE;
/*!40000 ALTER TABLE `positions` DISABLE KEYS */;
INSERT INTO `positions` VALUES (1,4,'Facility Accountant','Reporting to Facility Manager, this position oversees all financial analysis and reporting ...',NULL,'\0',''),(2,5,'I.T. Manager',NULL,NULL,'','\0');
/*!40000 ALTER TABLE `positions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_certifications`
--

DROP TABLE IF EXISTS `training_certifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_certifications` (
  `rec_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `course_id` int(11) DEFAULT NULL,
  `date_certified` date NOT NULL,
  `exp_date` date DEFAULT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`rec_id`),
  KEY `emp_id_idx` (`emp_id`),
  KEY `course_id_idx` (`course_id`),
  KEY `exp_date` (`exp_date`),
  CONSTRAINT `FK_cert_course_idx` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`course_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_emp_cert_idx` FOREIGN KEY (`emp_id`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_certifications`
--

LOCK TABLES `training_certifications` WRITE;
/*!40000 ALTER TABLE `training_certifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_certifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_classes`
--

DROP TABLE IF EXISTS `training_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_classes` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `instructor_id` int(11) DEFAULT NULL,
  `ext_instructor_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `schedule` varchar(15) DEFAULT NULL,
  `location` varchar(45) DEFAULT NULL,
  `completed` bit(1) NOT NULL DEFAULT b'0',
  `comments` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`class_id`),
  KEY `FK_class_course_idx_idx` (`course_id`),
  KEY `FK_class_emp_instructor_idx_idx` (`instructor_id`),
  KEY `FK_class_ext_instructor_idx` (`ext_instructor_id`),
  CONSTRAINT `FK_class_course_idx` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`course_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_class_emp_instructor_idx` FOREIGN KEY (`instructor_id`) REFERENCES `employee_main` (`emp_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_class_ext_instructor` FOREIGN KEY (`ext_instructor_id`) REFERENCES `ext_instructors` (`instructor_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_classes`
--

LOCK TABLES `training_classes` WRITE;
/*!40000 ALTER TABLE `training_classes` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_courses`
--

DROP TABLE IF EXISTS `training_courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_courses` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id` int(11) DEFAULT NULL,
  `course_name` varchar(45) NOT NULL,
  `course_desc` varchar(2048) DEFAULT NULL,
  `hours` int(11) DEFAULT NULL,
  `offsite` bit(1) DEFAULT NULL,
  `online` bit(1) DEFAULT NULL,
  `company_wide` bit(1) NOT NULL DEFAULT b'0',
  `frequency` varchar(15) DEFAULT NULL,
  `materials_reqd` varchar(1024) DEFAULT NULL,
  `reference_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`course_id`),
  KEY `vendor_id_idx` (`vendor_id`),
  KEY `course_name_idx` (`course_name`),
  CONSTRAINT `FK_course_vendor_idx` FOREIGN KEY (`vendor_id`) REFERENCES `training_vendors` (`vendor_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_courses`
--

LOCK TABLES `training_courses` WRITE;
/*!40000 ALTER TABLE `training_courses` DISABLE KEYS */;
INSERT INTO `training_courses` VALUES (1,1,'Microsoft Outlook Training',NULL,3,'\0','\0','','One-time','Instructional CD',NULL);
/*!40000 ALTER TABLE `training_courses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_requirements`
--

DROP TABLE IF EXISTS `training_requirements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_requirements` (
  `req_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `req_level` enum('Department','Position') DEFAULT NULL,
  `required_id` int(11) DEFAULT NULL COMMENT 'Department or Position ID',
  PRIMARY KEY (`req_id`),
  KEY `course_id_idx` (`course_id`),
  KEY `req_level_idx` (`req_level`),
  CONSTRAINT `FK_course_requirement_idx` FOREIGN KEY (`course_id`) REFERENCES `training_courses` (`course_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_requirements`
--

LOCK TABLES `training_requirements` WRITE;
/*!40000 ALTER TABLE `training_requirements` DISABLE KEYS */;
/*!40000 ALTER TABLE `training_requirements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `training_vendors`
--

DROP TABLE IF EXISTS `training_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `training_vendors` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_name` varchar(45) NOT NULL,
  `address_1` varchar(35) DEFAULT NULL,
  `address_2` varchar(35) DEFAULT NULL,
  `city` varchar(25) DEFAULT NULL,
  `state_province` varchar(10) DEFAULT NULL,
  `postal_code` varchar(15) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `fax` varchar(15) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`vendor_id`),
  KEY `vendor_name_idx` (`vendor_name`),
  KEY `city_idx` (`city`),
  KEY `state_idx` (`state_province`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `training_vendors`
--

LOCK TABLES `training_vendors` WRITE;
/*!40000 ALTER TABLE `training_vendors` DISABLE KEYS */;
INSERT INTO `training_vendors` VALUES (1,'Mentoris Training Systems','432 Rehoboth Drive',NULL,'Ocala','FL','34470','352-555-3521',NULL,NULL,NULL);
/*!40000 ALTER TABLE `training_vendors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hr_training'
--
/*!50003 DROP PROCEDURE IF EXISTS `getRequirements` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`127.0.0.1` PROCEDURE `getRequirements`(Dept VARCHAR(45), Position VARCHAR(45))
BEGIN

   SELECT TC.CourseID, TC.CourseName, TC.CourseDesc
   FROM TrainingCourses TC
   INNER JOIN PositionTraining PT
   ON PT.CourseID = TC.CourseID
        INNER JOIN Positions P
        ON P.PositionID = PT.PositionID
   WHERE PT.PositionTitle = Position

   UNION
   
   SELECT TC.CourseID, TC.CourseName, TC.CourseDesc
   FROM TrainingCourses TC
   INNER JOIN DeptTraining DT
   ON DT.CourseID = TC.CourseID
        INNER JOIN Departments D
        ON D.DeptID = DT.DeptID
   WHERE DT.DeptName = Dept;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `Incomplete_Training` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`127.0.0.1` PROCEDURE `Incomplete_Training`(EmployeeID INT)
BEGIN

SELECT course_name AS `Course Name` FROM
 
 (SELECT tc.course_id, tc.course_name, em.emp_id
     FROM training_requirements trDept
     INNER JOIN employee_main em
     ON em.dept_id = trDept.required_id
     INNER JOIN training_courses tc
     ON tc.course_id = trDept.course_id
     WHERE trDept.req_level = 'Department'
     AND em.emp_id = EmployeeID

     UNION

     SELECT tc.course_id, tc.course_name, em.emp_id
     FROM training_requirements trPos
     INNER JOIN employee_main em
     ON em.position_id = trPos.required_id
     INNER JOIN training_courses tc
     ON tc.course_id = trPos.course_id
     WHERE trPos.req_level = 'Position'
     AND em.emp_id = EmployeeID
 ) AS ReqUnion

  WHERE ReqUnion.emp_id = EmployeeID
  AND ReqUnion.course_id NOT IN
   (SELECT course_id FROM training_classes tc
    INNER JOIN class_registrations cr
    ON cr.class_id = tc.class_id
    WHERE cr.emp_id = EmployeeID
    AND cr.completed <> 0
    AND cr.passed <> 0);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `table_choice` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`127.0.0.1` PROCEDURE `table_choice`(reqLevel VARCHAR(10), itemID INT)
BEGIN

IF reqLevel = 'Department' THEN
	SELECT * FROM departments;
ELSE
	SELECT * FROM positions;
END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `current_employee_contact_list`
--

/*!50001 DROP VIEW IF EXISTS `current_employee_contact_list`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `current_employee_contact_list` AS select concat(`em`.`last_name`,', ',`em`.`first_name`,' ',`em`.`mid_name`) AS `Employee Name`,`em`.`badge_no` AS `Badge`,concat(`d`.`dept_number`,' - ',`d`.`dept_name`) AS `Department`,`em`.`shift` AS `shift`,`p`.`position_title` AS `position_title`,`ea`.`address_1` AS `address_1`,`ea`.`city` AS `city`,`ea`.`state_province` AS `state_province`,`ea`.`postal_code` AS `postal_code`,`ea`.`phone_1` AS `phone_1`,`ea`.`phone_2` AS `phone_2`,`ea`.`email` AS `email`,`em`.`emp_id` AS `emp_id` from (((`employee_main` `em` left join `employee_alt` `ea` on((`ea`.`emp_id` = `em`.`emp_id`))) left join `departments` `d` on((`d`.`dept_id` = `em`.`dept_id`))) left join `positions` `p` on((`p`.`position_id` = `em`.`position_id`))) where (`em`.`current` <> 0) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-22 22:23:22

CREATE DATABASE  IF NOT EXISTS `jobsearch_plus` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jobsearch_plus`;
-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: jobsearch_plus
-- ------------------------------------------------------
-- Server version	5.6.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activities` (
  `activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `lead_id` int(11) NOT NULL,
  `activity_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activity_type` varchar(30) NOT NULL,
  `activity_details` varchar(1024) DEFAULT NULL,
  `complete` bit(1) DEFAULT b'0',
  `reference_link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`activity_id`),
  KEY `activity_type_idx` (`activity_type`),
  KEY `FK_lead_id_idx_idx` (`lead_id`),
  KEY `activity_date_idx` (`activity_date`),
  CONSTRAINT `FK_activity_type_idx` FOREIGN KEY (`activity_type`) REFERENCES `activity_types` (`activity_type`) ON UPDATE CASCADE,
  CONSTRAINT `FK_lead_id_idx` FOREIGN KEY (`lead_id`) REFERENCES `leads` (`lead_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (2,1,'2015-08-03 00:00:00','Application',NULL,'\0',NULL),(3,1,'2015-08-05 00:00:00','Contact',NULL,'\0',NULL),(4,2,'2015-08-03 00:00:00','Application',NULL,'\0',NULL),(5,2,'2015-08-05 00:00:00','Interview',NULL,'\0',NULL);
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_types`
--

DROP TABLE IF EXISTS `activity_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_types` (
  `activity_type` varchar(30) NOT NULL,
  PRIMARY KEY (`activity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_types`
--

LOCK TABLES `activity_types` WRITE;
/*!40000 ALTER TABLE `activity_types` DISABLE KEYS */;
INSERT INTO `activity_types` VALUES ('Application'),('Closure'),('Contact'),('Correspondence'),('Documentation'),('Follow-up'),('Inquiry'),('Interview'),('Other');
/*!40000 ALTER TABLE `activity_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_types`
--

DROP TABLE IF EXISTS `business_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_types` (
  `business_type` varchar(30) NOT NULL,
  PRIMARY KEY (`business_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_types`
--

LOCK TABLES `business_types` WRITE;
/*!40000 ALTER TABLE `business_types` DISABLE KEYS */;
INSERT INTO `business_types` VALUES ('Information Technology');
/*!40000 ALTER TABLE `business_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) NOT NULL,
  `address1` varchar(75) DEFAULT NULL,
  `address2` varchar(75) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `co_state` char(2) DEFAULT NULL,
  `zip` char(10) DEFAULT NULL,
  `phone` char(14) DEFAULT NULL,
  `fax` char(14) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `website` varchar(50) DEFAULT NULL,
  `company_desc` varchar(1024) DEFAULT NULL,
  `business_type` varchar(30) DEFAULT NULL,
  `agency` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`company_id`),
  KEY `company_name_idx` (`company_name`),
  KEY `city_idx` (`city`),
  KEY `state_idx` (`co_state`),
  KEY `zip_idx` (`zip`),
  KEY `business_type_idx` (`business_type`),
  CONSTRAINT `FK_business_type_idx` FOREIGN KEY (`business_type`) REFERENCES `business_types` (`business_type`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'Jameson Corporation',NULL,NULL,'Boston','MA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0'),(2,'Alexis Systems',NULL,NULL,'Manchester','NH','03103',NULL,NULL,NULL,NULL,NULL,'Information Technology','\0'),(3,'Northeast Technologies',NULL,NULL,'Rochester','NY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),(4,'Nautica Supply',NULL,NULL,'Chicago','IL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0'),(5,'Denton Publishing',NULL,NULL,'Boise','ID',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0'),(6,'Galactix International',NULL,NULL,'New York','NY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'\0');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `courtesty_title` varchar(25) NOT NULL,
  `contact_first` varchar(35) DEFAULT NULL,
  `contact_last` varchar(35) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `phone` char(14) DEFAULT NULL,
  `fax` char(14) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `comments` varchar(1024) DEFAULT NULL,
  `active` bit(1) NOT NULL DEFAULT b'1',
  PRIMARY KEY (`contact_id`),
  KEY `last_name_idx` (`contact_last`),
  KEY `first_name_idx` (`contact_first`),
  KEY `company_id_idx` (`company_id`),
  CONSTRAINT `FK_contact_company_id_idx` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `leads`
--

DROP TABLE IF EXISTS `leads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leads` (
  `lead_id` int(11) NOT NULL AUTO_INCREMENT,
  `record_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `job_title` varchar(75) NOT NULL,
  `job_description` varchar(1024) DEFAULT NULL,
  `employment_type` enum('Full-time','Part-time','Contractor','Temp','Seasonal','Internal','Freelance','Volunteer') DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `active` bit(1) DEFAULT b'1',
  `company_id` int(11) DEFAULT NULL,
  `agency_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `source_id` int(11) DEFAULT NULL,
  `selected` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`lead_id`),
  KEY `record_date_idx` (`record_date`),
  KEY `job_title_idx` (`job_title`),
  KEY `employment_type_idx` (`employment_type`),
  KEY `FK_company_id_idx_idx` (`company_id`),
  KEY `FK_agency_id_idx_idx` (`agency_id`),
  KEY `FK_contact_id_idx_idx` (`contact_id`),
  KEY `FK_source_id_idx_idx` (`source_id`),
  FULLTEXT KEY `description_idx` (`job_description`),
  CONSTRAINT `FK_agency_id_idx` FOREIGN KEY (`agency_id`) REFERENCES `companies` (`company_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_company_id_idx` FOREIGN KEY (`company_id`) REFERENCES `companies` (`company_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_contact_id_idx` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`contact_id`) ON UPDATE CASCADE,
  CONSTRAINT `FK_source_id_idx` FOREIGN KEY (`source_id`) REFERENCES `sources` (`source_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='Main job leads table	';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leads`
--

LOCK TABLES `leads` WRITE;
/*!40000 ALTER TABLE `leads` DISABLE KEYS */;
INSERT INTO `leads` VALUES (1,'2015-07-09 22:46:13','Database Administrator',NULL,'Full-time','Atlanta, GA','',4,NULL,NULL,NULL,'\0'),(2,'2015-07-09 22:46:33','Database Programmer',NULL,'Full-time','Atlanta, GA','',4,NULL,NULL,2,'\0'),(3,'2015-07-09 22:47:59','Software Developer',NULL,'Full-time','Atlanta, GA','',2,NULL,NULL,NULL,'\0'),(4,'2015-07-09 23:16:31','Database Administrator',NULL,'Full-time','Montgomery, AL','',5,NULL,NULL,NULL,'\0'),(5,'2015-07-09 23:16:31','Data Warehouse Manager',NULL,'Full-time','Montgomery, AL','',5,NULL,NULL,NULL,'\0'),(6,'2015-09-07 22:15:02','Data Warehouse Manager',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'\0');
/*!40000 ALTER TABLE `leads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `multi_lead`
--

DROP TABLE IF EXISTS `multi_lead`;
/*!50001 DROP VIEW IF EXISTS `multi_lead`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `multi_lead` AS SELECT 
 1 AS `job_title`,
 1 AS `employment_type`,
 1 AS `company_name`,
 1 AS `job_description`,
 1 AS `location`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `sources`
--

DROP TABLE IF EXISTS `sources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sources` (
  `source_id` int(11) NOT NULL AUTO_INCREMENT,
  `source_name` varchar(50) NOT NULL,
  `source_type` varchar(50) NOT NULL,
  `source_link` varchar(255) DEFAULT NULL,
  `source_desc` varchar(1024) DEFAULT NULL,
  PRIMARY KEY (`source_id`),
  KEY `source_name_idx` (`source_name`),
  KEY `source_type_idx` (`source_type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sources`
--

LOCK TABLES `sources` WRITE;
/*!40000 ALTER TABLE `sources` DISABLE KEYS */;
INSERT INTO `sources` VALUES (1,'CareerBuilder.com','Website','http://www.careerbuilder.com','Job Board'),(2,'Northeast Referral Network','Professional Network','','Professional Network');
/*!40000 ALTER TABLE `sources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'jobsearch_plus'
--
/*!50003 DROP PROCEDURE IF EXISTS `recentLeads` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`admin`@`127.0.0.1` PROCEDURE `recentLeads`()
BEGIN

SELECT * FROM leads
ORDER BY record_date desc
LIMIT 10;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `multi_lead`
--

/*!50001 DROP VIEW IF EXISTS `multi_lead`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`admin`@`127.0.0.1` SQL SECURITY DEFINER */
/*!50001 VIEW `multi_lead` AS select `l`.`job_title` AS `job_title`,`l`.`employment_type` AS `employment_type`,`c`.`company_name` AS `company_name`,`l`.`job_description` AS `job_description`,`l`.`location` AS `location` from (`companies` `c` left join `leads` `l` on((`c`.`company_id` = `l`.`company_id`))) where `l`.`location` in (select `l`.`location` from `leads` `l` where (`l`.`active` <> 0) group by `l`.`location` having (count(`l`.`lead_id`) > 1)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-22 22:24:02

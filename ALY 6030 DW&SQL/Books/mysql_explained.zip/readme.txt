MySQL Explained Supplemental Files

This file contains the SQL scripts for the three example databases used in MySQL Explained:

Job Search Plus contact and job search manager
SpheraTech HR & Training database
Recipes database

The scripts can be used to create the databases using the MySQL Workbench Data Import / Restore function. Database diagrams of the three databases are also included in JPG format for reference.

If you have any questions or issues with these files, please contact me directly at acomeau@comeausoftware.com.

Andrew Comeau
October 2015